# edr — Energy-constrained UAV–UGV routing under dynamic roads

Implementation of the project in `../context/RM_IIT2024036_IIT2024081_IIT2024146 (1).pdf`
(*Energy-Constrained UAV–UGV Replanning under Dynamic Road Conditions*), built on the base paper
`../context/p1.pdf` (Mondal et al., arXiv:2504.21111). **Not** the friend's project (learned virtual-slot
assignment); the UAV→UGV assignment here is the base paper's frozen greedy rule.

Units: km, min, kJ. Everything below was run on a CPU-only laptop (12 cores, no GPU).

## What is implemented

| Deck element | Where |
|---|---|
| Base environment: sortie-wise UAV/UGV switching, fuel mask, greedy UAV→UGV assignment, one UAV per UGV, `T_R`, penalty | `src/edr/env.py` |
| UAV power model `P(v)`, battery 287.7 kJ, speeds | `src/edr/params.py` |
| Mission energy `E = Σ P_fly·t_fly + P_wait·t_wait`, budget `B = β·B0` | `env.py`, `evaluate.py` |
| Road model: normal / slow (×κ) / blocked edges; events by type × level × timing; "policy learns only when it occurs" | `roads.py`, `events.py` |
| Road graph **with loops** (so a blockage has a detour) + a branching tree for the base check | `roads.py` |
| Transformer encoder–decoder policy (3-layer 8-head encoder, context vector, glimpse, clipped scores, masks) | `model.py` |
| Candidate B: remaining-budget input `b_t` | `model.py` (`use_budget`) |
| REINFORCE with greedy-rollout baseline (paper Alg. 1) and group-baseline fine-tuning | `rl.py` |
| P0 base · P1 route filter · P2 fixed penalty · P3 Lagrangian (candidate A, dual ascent) · P4 budget-conditioned (candidate B) | `rl.py`, `evaluate.py`, `scripts/train.py` |
| Dynamic road layer: reachability + "on-time" action masks on the current roads | `env.py` (`road_aware`, `projected_wait`) |
| Open-loop / periodic / event-triggered replanning (keep completed route, replan the rest) | `plan.py` |
| Hand-checkable 1U-1G, 3-task case; `E = ΣP·t`; hover vs landed waiting | `tests/test_env.py` |
| Ablations: remove budget input, fixed vs Lagrangian, none/periodic/event, train with/without road events, Euclid vs road assignment | `scripts/experiments.py` |
| Stages A (static budgets), B (blocked/slow roads), stress test (disconnecting block), M1 trend check | `scripts/experiments.py`, `scripts/validate_m1.py` |
| Demonstration simulation (open-loop vs event-triggered, same instance and event) | 2D video: `scripts/make_animation.py`, `src/edr/viz.py`; **3D browser viewer** (Three.js, 4 scenarios): `scripts/export_viewer_data.py` → `scripts/build_viewer.py` → `viewer/index.html` (self-contained, open it directly in a browser) |

## Maps

`paper` (the base paper's exact road, reconstructed from the authors' code), `loop` (our first map; all results above), `grid`, `radial`, `geo`, and `border`
(army border surveillance: patrol road, supply road, connectors, forward outposts, surveillance strip). `results/maps.png` draws them; `results/map_study.csv`
compares how much events matter on each (rule-based policy: `border` most, `radial` least). Select with `--roads <name>`; model/result folders carry the map name.

## Run on Kaggle (heavy training)

```bash
.venv/bin/python scripts/package_for_kaggle.py --user vichanshur        # builds kaggle/ (nothing is uploaded)
kaggle datasets create -p kaggle/dataset                                # private dataset with the code
kaggle kernels push -p kaggle/kernels/edr-border                        # one kernel per map; 2 at a time is typical
kaggle kernels status vichanshur/edr-border
kaggle kernels output vichanshur/edr-border -p out/border               # results_bundle.zip
```

Each kernel trains P0 + 6 variants x 3 seeds for its map and runs Stages A, B, S (resumable; CPU, no internet needed).

## Run

```bash
cd implementation
.venv/bin/python -m pytest                                   # 29 tests
.venv/bin/python scripts/train.py p0 --uav 2 --ugv 1         # imitation warm start + REINFORCE
.venv/bin/python scripts/train.py ft --uav 2 --ugv 1 --variant p0c --variant p2 --variant p3_b90 --variant p4 ...
.venv/bin/python scripts/experiments.py A|B|S --uav 2 --ugv 1 --n 100
.venv/bin/python scripts/make_figures.py --tag U15G5_2U1G && .venv/bin/python scripts/make_report.py
.venv/bin/python scripts/make_animation.py --kind slow --level high --timing early --gif
```

Outputs: `results/REPORT.md` (all tables with 95 % CIs and paired differences), `results/<tag>/figures/*.png`,
`results/<tag>/media/mission_*.{mp4,gif,png}` (the simulation), `results/validation/m1_trends.csv`,
`results/<tag>/stage*.csv` (raw per-instance rows), `results/logs/` (training logs), `results/models/` (checkpoints,
training curves).

## Results (U15G5, 100 held-out instances, **one training seed**, ± = 95 % CI)

**M1 – base comparison on the paper's own map.** Mean mission time, static roads, 100 instances (min). `paper` = the base paper's exact road
(reconstructed from the authors' code); local training only (600 imitation + 400 REINFORCE steps; Kaggle runs use 800 + 1200):

| | 1U-1G | 2U-1G | 2U-2G | 4U-2G |
|---|---|---|---|---|
| paper DRL (greedy) | 238.2 | 229.7 | 180.5 | 188.9 |
| paper DRL (10240 samples) | 218.6 | 199.7 | 154.4 | 159.9 |
| ours, rule, paper map | 271.9 | 245.5 | 202.1 | 215.5 |
| **ours, trained P0 greedy, paper map** | **271.2** | **254.8** | **201.5** | **225.7** |
| ours, trained P0 greedy, loop map | – | 194.7 | 169.7 | – |

The team ordering matches the paper (more UGVs help a lot; 4U-2G ≈ 2U-2G). **Our P0 is 11-19 % slower than the paper's greedy DRL on the paper's own map**
and is about as good as the rule it was warm-started from, so it is *not* a faithful reproduction of the paper's trained policy (training here is ~4 orders of
magnitude smaller). One rule-policy instance fails on the paper map (2U-1G and 2U-2G) and is excluded. The longer Kaggle runs may narrow the gap.

**Hypotheses** (2U-1G; 2U-2G in `results/REPORT.md`):

* **H3 supported (time/energy).** Open-loop base policy, event vs same instance on static roads: block +14…18 % T / +20…27 % E;
  slow low→high +3→18 % T / +4.5→25 % E; early events cost most (+29 % E) and late ones least (+6.6 %).
  Failures stay ≈0 while the road stays connected; they only appear when a bridge is cut (below).
* **H4 supported.** Event-triggered vs periodic replanning, same policy and events: ΔT = +0.1 ± 0.1 min (P0), 0.0 (P4);
  replans 0.47 vs 2.45. Road layer + event-triggered replanning vs open loop: −11.6 ± 1.0 min and −271 ± 24 kJ (−6.6 %) for P0.
* **H1 not supported as stated.** In this environment time and energy move together: faster routes wait less, so they also
  use less energy (P1 route filter: −19 % T *and* −25 % E vs greedy P0). There is no visible trade-off to exploit; min-time and
  min-energy routes nearly coincide (P1 at β=0.7 vs 1.0 differ by 20 kJ). The deck lists this as a risk.
* **H2 not supported / inconclusive.** P3 (Lagrangian) vs P2 (fixed penalty) are not distinguishable (β=0.9: 53 % vs 62 % over
  budget, paired ΔT, ΔE CIs include 0), and λ **saturated at its cap (8)** for β=0.8 and 0.9: the policy never became
  feasible, so "λ converges" (M2 exit criterion) was **not** met. β=0.7 is out of reach for every learned policy.
* **Candidate methods vs the P0+ control** (same extra fine-tuning, road layer + event-triggered, Stage B 2U-1G):
  P4 −7.8 ± 2.0 min / −165 ± 49 kJ, P3 −7.9 / −214 kJ. On 2U-2G only P3 beats the control and P4 does not (+0.1 ± 5.8 min in Stage A).
  Because there is **one training seed**, these differences cannot be separated from training-seed variance.
* **Budget input ablation:** P4 vs P4 without the budget input: no clear difference (Stage A over-budget 53 % vs 60 % at β=0.9, 2U-1G).
* **Training with road events** (P4_ev, P0_ev) was not better than static training (T 193 vs 190 min).
* **Euclid vs road distance for assignment** (2U-2G): no significant effect (dT −0.4…+1.8 ± ≥0.9 min). With one UGV it is trivially identical.
* **P1 (route filter) is the strongest method by a wide margin** (T 157 vs 189, E 2585 vs 3350 for the control; over-budget 20 % at β=0.9,
  0 % at 1.0) — it is search at inference time (64 samples/instance), i.e. it spends compute the learned policies are meant to amortise.
  Our learned policies, trained for minutes on a CPU, do not close that gap (the paper's own sampling-vs-greedy gap is ~12 %; ours is 19 %).
* **Stress test (disconnecting bridge):** failure 85 % → 68 % (P0, open → event-triggered, 2U-1G) and 75 % → 52 % (2U-2G). Most failures are
  unavoidable because UAVs have just committed nearly empty batteries; diversion needs spare fuel. A fuel reserve policy is future work.

![](results/U15G5_2U1G/figures/stageB_replanning.png)

## Energy trade-off diagnostic (why H1/H2 do not show up) — `scripts/tradeoff_study.py`

60 instances x 128 sampled routes from P0 (loop map, 2U-1G). Per instance, the lowest-energy route vs the fastest route:

| energy model | corr(T, E) | lowest-E route: extra time | energy it saves | Pareto routes |
|---|---|---|---|---|
| hover waiting (as modelled, 229.6 W) | 0.96 | +0.7 % | 0.9 % | 1.4 |
| hover power x 0.5 | 0.97 | +0.3 % | 0.6 % | 1.4 |
| hover power x 0.25 | 0.90 | +2.1 % | 1.2 % | 1.8 |
| **landed waiting (free)** | **0.39** | **+23.2 %** | **7.9 %** | 3.8 |

* With hover waiting, time and energy are almost the same objective: there is nothing to trade, so an energy-aware method cannot beat a time-optimal one by much. A real trade-off appears only when waiting is free, and then it is expensive (about +3 % time per 1 % energy).
* Stage A re-run under landed waiting (`--wait-mode landed`, models in `results/models/U15G5_2U1G_landed`, 100 instances): P0 greedy E = 1553 kJ; **P1 route filter** moves along a visible Pareto curve (beta 1.0: T 164 / E 1454; beta 0.9: T 176 / E 1399; beta 0.8: T 184 / E 1376, over-budget 0 % / 47 % / 89 %); the learned P2, P3, P4 (T 181-190, E 1427-1506) are not better than the P0+ control (T 178, E 1440).
* **Finding about candidate B (budget-conditioned P4):** its output is identical for every beta. The learned weight on the budget input is ~10x smaller than on the other inputs (0.005 vs 0.053). A variant with a "pace" feature (remaining budget minus remaining work) and 10x learning rate on it (`p4x`, weights now 0.095) is still beta-independent after 600 steps. So at this training scale the policy does not use the budget; the energy lever is too weak to learn.
* Consequence: report H1/H2 honestly as "not supported under hover waiting; a small, costly trade-off exists only with free waiting", and treat search (P1) as the method that actually meets budgets.

## Deviations from the base paper / deck, and assumptions (please read)

1. **Training scale.** Paper: 5.12 M instances on an RTX 4090. Ours: CPU, ~600 imitation + 400 REINFORCE steps (batch 64) for P0 and
   200–400 fine-tuning steps per variant (group baseline, 8 samples/instance, lr 3e-4, advantage standardisation). P0 is warm-started by
   behaviour-cloning a nearest-feasible rule. The first fine-tuning attempt with the paper's greedy baseline for 200 steps barely moved the
   policy (E −1…−5 %; kept in `results/models/U15G5_2U1G/v1_greedy_baseline/`), hence the group baseline.
2. **One training seed**, not three (deck: 3). CIs are over test instances only.
3. **Decoder** adds two dynamic geometry features (distance from current position; for landings, distance to nearest unvisited task) and uses
   **LayerNorm** instead of BatchNorm (BN in eval mode misbehaved at batch size 1). Encoder otherwise as in the paper.
4. **`T_R = 15 min`**, road geometry, depot choice, UGV service order (earliest touchdown first) are assumptions — not stated in the paper text.
5. **Waiting energy:** hover waiting is charged to mission energy `E` at `P(0) = 229.6 W`; the per-sortie battery constraint `F_a` covers flight only
   (as in the base paper). A `landed` wait mode (0 W) exists for the unit test. Hover waiting is ~40–70 % of `E`, which is why time and energy are so aligned.
6. **Replanning happens at round boundaries** (completed route kept). Mid-round, a UAV whose rendezvous is cut off may *divert* on its remaining
   battery (enabled for periodic/event, not open-loop).
7. **P4's loss** is not specified in the deck; we use a fixed hinge `κ·T_ref·(E−B)₊/B0`, κ = 3. P3 uses dual ascent with step 0.1, cap 8.
   `t_ref` (scale only) is the mean P0 validation time, inflated by one failed instance (269 min for 2U-1G).
8. **B0** is P0's greedy energy on the same static instance (instances where P0 itself fails are skipped in the test set; in training the rule-based run is used).
9. **Test events** are placed on the UGV's upcoming drive in the base policy's static run, so every event bites; "blocked" events keep the graph connected except in the stress test.
10. Metaheuristic baselines (GLS/TS/SA with OR-Tools) and Stage C (larger sizes), Gazebo integration were **not** implemented.
