#!/usr/bin/env python
"""Inline viewer/missions.json into viewer/template.html -> viewer/index.html (single self-contained page)."""
import os
root = os.path.join(os.path.dirname(__file__), "..", "viewer")
data = open(os.path.join(root, "missions.json")).read()
html = open(os.path.join(root, "template.html")).read().replace("__DATA__", data)
open(os.path.join(root, "index.html"), "w").write(html)
print("wrote viewer/index.html", len(html) // 1024, "KB")
