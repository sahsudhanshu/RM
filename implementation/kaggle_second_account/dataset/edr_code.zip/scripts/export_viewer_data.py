#!/usr/bin/env python
"""Export demo missions (open-loop vs event-triggered, same instance + road event) as JSON for the 3D viewer."""
import json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np, torch
from edr.evaluate import build_cases, greedy_planner, load_model
from edr.plan import run_controller
from edr.rl import Setting, new_env

ROOT = os.path.join(os.path.dirname(__file__), "..")
torch.set_num_threads(2)
s = Setting(n_uav=2, n_ugv=1)
base = load_model(os.path.join(ROOT, "results", "models", s.tag, "p0.pt"))
cases = build_cases(s, base, 40)
COMBOS = [("slow", "high", "early"), ("block", "medium", "middle"), ("slow", "medium", "late"), ("block", "high", "early")]
r3 = lambda x: round(float(x), 3)


def pack(res, info, scn):
    xy = scn.xy
    legs = []
    for (u, t0, t1, p0, p1, kind, e, rnd) in res.legs:
        task = int(np.argmin(np.linalg.norm(xy - np.array(p1), axis=1)))
        legs.append([u, r3(t0), r3(t1), r3(p0[0]), r3(p0[1]), r3(p1[0]), r3(p1[1]), 1 if kind == "land" else 0, r3(e), rnd, task])
    return dict(
        T=r3(res.makespan), E=r3(res.energy), wait=r3(res.wait_time), replans=info.replans, failed=bool(res.failed),
        legs=legs,
        services=[[sv["uav"], sv["ugv"], r3(sv["touchdown"]), r3(sv["start"]), r3(sv["end"]), sv["node"]] for sv in res.services],
        drives=[[d[0], r3(d[1]), r3(d[2]), d[3], d[4], d[5], d[6]] for d in res.ugv_drives],
    )


out, used = [], set()
for kind, level, timing in COMBOS:
    best = None
    for c in cases:
        if c.seed in used:
            continue
        ev = c.event(kind, level, timing)
        runs = []
        for mode, aware in (("open", False), ("event", True)):
            env = new_env(s, c.scn, events=(ev,), road_aware=aware)
            runs.append(run_controller(env, greedy_planner(base), mode))
        gain = runs[0][0].cost - runs[1][0].cost
        if best is None or gain > best[0]:
            best = (gain, c, ev, runs)
    gain, c, ev, runs = best
    used.add(c.seed)
    rm = c.scn.roads
    out.append(dict(
        id=f"{kind}-{level}-{timing}", title=f"{kind.capitalize()} edges, {level}, {timing} in the mission", seed=int(c.seed),
        roads=dict(xy=[[r3(a), r3(b)] for a, b in rm.xy], edges=[list(map(int, e)) for e in rm.edges]),
        tasks=dict(xy=[[r3(a), r3(b)] for a, b in c.scn.xy], n_ground=c.scn.n_ground, node=[int(n) for n in c.scn.node], depot=int(c.scn.depot_task)),
        event=dict(t=r3(ev.t), kind=ev.kind, edges=list(ev.edges), kappa=ev.kappa),
        budget=r3(0.9 * c.b0), static=dict(T=r3(c.t0), E=r3(c.b0)),
        open=pack(runs[0][0], runs[0][1], c.scn), event_run=pack(runs[1][0], runs[1][1], c.scn),
    ))
    o, e = out[-1]["open"], out[-1]["event_run"]
    print(out[-1]["id"], "seed", c.seed, f"open T={o['T']:.0f} E={o['E']:.0f} | event T={e['T']:.0f} E={e['E']:.0f} replans={e['replans']}")
meta = dict(fuel=287.7, recharge=15.0, hover_kj_per_min=13.776, cases=out)
path = os.path.join(ROOT, "viewer", "missions.json")
json.dump(meta, open(path, "w"), separators=(",", ":"))
print("wrote", path, os.path.getsize(path) // 1024, "KB")
